"""Stage-1 Vertex AI training package for Liquid LLM."""

from .cli import main

__all__ = ["main"]
